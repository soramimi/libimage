This directory (contrib/tools) contains tools used by the authors of libpng.

Code and data placed in this directory is not required to build libpng,
however the code in this directory has been used to generate data or code in
the body of the libpng source.  The source code identifies where this has
been done.  Code in this directory may not compile on all operating systems
that libpng supports.

NO COPYRIGHT RIGHTS ARE CLAIMED TO ANY OF THE FILES IN THIS DIRECTORY.

To the extent possible under law, the authors have waived all copyright and
related or neighboring rights to this work.  This work is published from:
United States.

The files may be used freely in any way.

The source code and comments in this directory are the original work of the
people named below.  No other person or organization has made contributions to
the work in this directory.

ORIGINAL AUTHORS
    The following people have contributed to the code in this directory.  None
    of the people below claim any rights with regard to the contents of this
    directory.

    John Bowler <jbowler at acm.org>
    Glenn Randers-Pehrson <glennrp at users.sourceforge.net>
